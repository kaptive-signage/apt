#!/bin/sh
# Regenerates /etc/nginx/kaptive-resolver.conf from /etc/resolv.conf.
#
# nginx does not read /etc/resolv.conf itself, but proxy_pass with a
# variable (used by the iframe proxy on :3612) requires an explicit
# `resolver` directive. This only affects DNS lookups nginx performs for
# proxied iframe targets - it does not touch system DNS/networking.
# DNS servers can change per network (NetworkManager), so this script is
# re-run on network change by the NetworkManager dispatcher script.
# Falls back to public resolvers if none are found.
#
# Safe by construction: the new config is only applied if `nginx -t`
# accepts it, and nginx is reloaded (not restarted), so a bad write or a
# transient failure here cannot drop the already-running player on :3611.

NS=$(awk '/^nameserver [0-9.]+$/ { printf "%s ", $2 }' /etc/resolv.conf 2>/dev/null)
[ -z "$NS" ] && NS="1.1.1.1 8.8.8.8 "

NEW="resolver ${NS}valid=30s ipv6=off;"
CUR=$(cat /etc/nginx/kaptive-resolver.conf 2>/dev/null)

if [ "$NEW" != "$CUR" ]; then
    printf '%s\n' "$NEW" > /etc/nginx/kaptive-resolver.conf
    nginx -t >/dev/null 2>&1 && systemctl reload nginx >/dev/null 2>&1 || true
fi
