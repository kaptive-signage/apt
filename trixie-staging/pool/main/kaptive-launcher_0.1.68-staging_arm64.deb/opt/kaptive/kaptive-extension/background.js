const STRIP = [
  "x-frame-options",
  "content-security-policy",
  "content-security-policy-report-only",
];

chrome.webRequest.onHeadersReceived.addListener(
  (details) => ({
    responseHeaders: (details.responseHeaders || []).filter(
      (h) => !STRIP.includes(h.name.toLowerCase())
    ),
  }),
  { urls: ["<all_urls>"], types: ["sub_frame"] },
  ["blocking", "responseHeaders", "extraHeaders"]
);
